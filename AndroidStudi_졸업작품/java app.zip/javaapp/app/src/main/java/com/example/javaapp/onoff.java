package com.example.javaapp;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.interfaces.datasets.ILineDataSet;

import org.json.JSONObject;

import java.net.URISyntaxException;
import android.widget.CompoundButton;
import android.widget.Switch;
import android.widget.Toast;


public class onoff extends AppCompatActivity {
    private Socket mSocket;
    TextView text11;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onoff);

        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                Intent intent = new Intent(onoff.this,MainActivity.class);
                startActivity(intent);
            }
        });

        try {
            mSocket = IO.socket("//희망url");
            mSocket.connect();
            text11.setText("server connect");
            mSocket.on(Socket.EVENT_CONNECT,onoff1);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        }

        Switch ons = findViewById(R.id.ons);
        ons.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean isChecked) {

                if(isChecked) {
                    mSocket.emit("poweron");
                    mSocket.on("poweronok", onoff3);
                }
                else{
                        mSocket.emit("powerff");
                        mSocket.on("poweroffok",onoff4);

                    }
                }
        });

    }
    Emitter.Listener onoff1 = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            mSocket.emit("connect");
        }
    };
    Emitter.Listener onoff3 = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Toast.makeText(getApplicationContext(),"poweron",Toast.LENGTH_SHORT).show();
        }
    };
    Emitter.Listener onoff4 = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            Toast.makeText(getApplicationContext(),"poweroff",Toast.LENGTH_SHORT).show();
        }
    };
}